﻿using System;
using System.Xml;
using System.Windows.Forms;

namespace Practica2_XML
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        private void CargarInterfaz()
        {
            XmlDocument xmlDoc = CargarFicheroConfigInterfaz();
            XmlDocument xmlDocCatalogo = CargarCatalogo();

            CargarBotones(xmlDoc, xmlDocCatalogo);
            CargarEtiquetas(xmlDoc);
            CargarCamposDeTexto(xmlDoc);

        }

        private void CargarBotones(XmlDocument xmlDoc, XmlDocument xmlDocCatalogo)
        {
            XmlNodeList nodosBoton = xmlDoc.SelectNodes("Interfaz/Buttons/Button");

            foreach (XmlNode nodoBoton in nodosBoton)
            {
                string buttonName = nodoBoton["Name"]?.InnerText;
                string buttonText = nodoBoton["Text"]?.InnerText;
                int locationX = int.Parse(nodoBoton["LocationX"]?.InnerText ?? "0");
                int locationY = int.Parse(nodoBoton["LocationY"]?.InnerText ?? "0");
                int width = int.Parse(nodoBoton["Width"]?.InnerText ?? "100");
                int height = int.Parse(nodoBoton["Height"]?.InnerText ?? "30");

                Button boton = new Button()
                {
                    Name = buttonName,
                    Text = buttonText,
                    Location = new System.Drawing.Point(locationX, locationY),
                    Size = new System.Drawing.Size(width, height)
                };

                boton.Click += (sender, e) =>
                {
                    Button botonPresionado = sender as Button;
                    if (botonPresionado != null)
                    {
                        if (botonPresionado.Name == "btmAñadirJuego")
                        {
                            AñadirJuego(xmlDocCatalogo);
                        }
                        else if (botonPresionado.Name == "btnModificarJuego")
                        {
                            ModificarJuego(xmlDocCatalogo);
                        }
                        else if (botonPresionado.Name == "btnEliminarJuego")
                        {
                            EliminarJuego(xmlDocCatalogo);
                        }
                    }
                };

                this.Controls.Add(boton);
            }
        }

        private void CargarEtiquetas(XmlDocument xmlDoc)
        {
            XmlNodeList nodosLabel = xmlDoc.SelectNodes("Interfaz/Labels/Label");
            foreach (XmlNode nodoLabel in nodosLabel)
            {
                string labelName = nodoLabel["Name"]?.InnerText;
                string labelText = nodoLabel["Text"]?.InnerText;
                int locationX = int.Parse(nodoLabel["LocationX"]?.InnerText ?? "0");
                int locationY = int.Parse(nodoLabel["LocationY"]?.InnerText ?? "0");
                int width = int.Parse(nodoLabel["Width"]?.InnerText ?? "200");
                int height = int.Parse(nodoLabel["Height"]?.InnerText ?? "30");

                Label label = new Label()
                {
                    Name = labelName,
                    Text = labelText,
                    Location = new System.Drawing.Point(locationX, locationY),
                    Size = new System.Drawing.Size(width, height)
                };

                this.Controls.Add(label);
            }
        }

        private void CargarCamposDeTexto(XmlDocument xmlDoc)
        {
            XmlNodeList nodosTextField = xmlDoc.SelectNodes("Interfaz/TextFields/TextField");
            foreach (XmlNode nodoTextField in nodosTextField)
            {
                string textFieldName = nodoTextField["Name"]?.InnerText;
                string textFieldText = nodoTextField["Text"]?.InnerText;
                int locationX = int.Parse(nodoTextField["LocationX"]?.InnerText ?? "0");
                int locationY = int.Parse(nodoTextField["LocationY"]?.InnerText ?? "0");
                int width = int.Parse(nodoTextField["Width"]?.InnerText ?? "200");
                int height = int.Parse(nodoTextField["Height"]?.InnerText ?? "30");

                TextBox textBox = new TextBox()
                {
                    Name = textFieldName,
                    Text = textFieldText,
                    Location = new System.Drawing.Point(locationX, locationY),
                    Size = new System.Drawing.Size(width, height)
                };

                this.Controls.Add(textBox);
            }
        }


        // FUNCIONES DE LOS BOTONES
        // AÑADIR JUEGO
        private void AñadirJuego(XmlDocument xmlDoc)
        {
            // Obtener el próximo ID autoincremental y los valores de los campos de texto
            string id = ObtenerProximoID(xmlDoc);
            string titulo = ((TextBox)this.Controls["txtTitulo"]).Text;
            string genero = ((TextBox)this.Controls["txtGenero"]).Text;
            string desarrollador = ((TextBox)this.Controls["txtDesarrollador"]).Text;
            string precio = ((TextBox)this.Controls["txtPrecio"]).Text;

            // Verificar si el videojuego ya existe en el XML
            if (VideojuegoExiste(xmlDoc, titulo))
            {
                MessageBox.Show("El videojuego con ese título ya existe en el catálogo.");
                return;
            }

            // Validación de campos
            if (EsValorPorDefecto(titulo) || EsValorPorDefecto(genero) || EsValorPorDefecto(desarrollador))
            {
                MessageBox.Show("Por favor, ingrese valores válidos en todos los campos.");
                return;
            }

            // Verificar que los campos no estén vacíos
            if (string.IsNullOrEmpty(titulo) || string.IsNullOrEmpty(genero) || string.IsNullOrEmpty(desarrollador) || string.IsNullOrEmpty(precio))
            {
                MessageBox.Show("Por favor, rellene todos los campos.");
                return;
            }

            // Crear un nuevo nodo <Videojuego> en el XML
            XmlNode catalogoNode = xmlDoc.SelectSingleNode("Catalogo");

            XmlNode nuevoVideojuego = xmlDoc.CreateElement("Videojuego");

            XmlNode idNode = xmlDoc.CreateElement("ID");
            idNode.InnerText = id;
            nuevoVideojuego.AppendChild(idNode);

            XmlNode tituloNode = xmlDoc.CreateElement("Titulo");
            tituloNode.InnerText = titulo;
            nuevoVideojuego.AppendChild(tituloNode);

            XmlNode generoNode = xmlDoc.CreateElement("Genero");
            generoNode.InnerText = genero;
            nuevoVideojuego.AppendChild(generoNode);

            XmlNode desarrolladorNode = xmlDoc.CreateElement("Desarrollador");
            desarrolladorNode.InnerText = desarrollador;
            nuevoVideojuego.AppendChild(desarrolladorNode);

            XmlNode precioNode = xmlDoc.CreateElement("Precio");
            precioNode.InnerText = precio;
            nuevoVideojuego.AppendChild(precioNode);

            // Añadir el nuevo videojuego al catálogo
            catalogoNode.AppendChild(nuevoVideojuego);

            // Guardar el archivo XML con el nuevo videojuego
            xmlDoc.Save("Catalogos/catalogo.xml");

            // Mostrar mensaje de éxito
            MessageBox.Show("¡Nuevo videojuego añadido al catálogo!");
        }
        private string ObtenerProximoID(XmlDocument xmlDoc)
        {
            XmlNode catalogoNode = xmlDoc.SelectSingleNode("Catalogo");

            // Obtener todos los nodos Videojuego
            XmlNodeList videojuegos = catalogoNode.SelectNodes("Videojuego");

            int maxID = 0;
            foreach (XmlNode videojuego in videojuegos)
            {
                XmlNode idNode = videojuego.SelectSingleNode("ID");
                if (idNode != null && int.TryParse(idNode.InnerText, out int id))
                {
                    maxID = Math.Max(maxID, id);
                }
            }

            // El próximo ID es el siguiente número mayor
            return (maxID + 1).ToString();
        }
        // Función para verificar si un videojuego ya existe por título
        private bool VideojuegoExiste(XmlDocument xmlDoc, string titulo)
        {
            XmlNode catalogoNode = xmlDoc.SelectSingleNode("Catalogo");

            // Buscar si ya existe un videojuego con el mismo título
            XmlNode videojuegoNode = catalogoNode.SelectSingleNode($"Videojuego[Titulo='{titulo}']");

            return videojuegoNode != null;
        }

        // MODIFICAR JUEGO
        private void ModificarJuego(XmlDocument xmlDoc)
        {
            // Obtener el título del videojuego desde el campo de texto
            string titulo = ((TextBox)this.Controls["txtTitulo"]).Text;

            // Verificar si el título es válido
            if (EsValorPorDefecto(titulo) || string.IsNullOrEmpty(titulo))
            {
                MessageBox.Show("Por favor, ingrese un título válido para modificar el videojuego.");
                return;
            }

            // Buscar el videojuego por título
            XmlNode catalogoNode = xmlDoc.SelectSingleNode("Catalogo");
            XmlNode videojuegoNode = catalogoNode.SelectSingleNode($"Videojuego[Titulo='{titulo}']");

            // Si no se encuentra el videojuego
            if (videojuegoNode == null)
            {
                MessageBox.Show("No se ha encontrado un videojuego con ese título.");
                return;
            }

            // Obtener los valores de los campos de texto
            string nuevoTitulo = ((TextBox)this.Controls["txtTitulo"]).Text;
            string nuevoGenero = ((TextBox)this.Controls["txtGenero"]).Text;
            string nuevoDesarrollador = ((TextBox)this.Controls["txtDesarrollador"]).Text;
            string nuevoPrecio = ((TextBox)this.Controls["txtPrecio"]).Text;

            // Validar si los campos tienen valores por defecto
            if (EsValorPorDefecto(nuevoTitulo) || EsValorPorDefecto(nuevoGenero) || EsValorPorDefecto(nuevoDesarrollador) || EsValorPorDefecto(nuevoPrecio))
            {
                MessageBox.Show("Por favor, ingrese valores válidos en todos los campos.");
                return;
            }

            // Modificar los valores del videojuego
            videojuegoNode["Titulo"].InnerText = nuevoTitulo;
            videojuegoNode["Genero"].InnerText = nuevoGenero;
            videojuegoNode["Desarrollador"].InnerText = nuevoDesarrollador;
            videojuegoNode["Precio"].InnerText = nuevoPrecio;

            // Guardar el archivo XML con los cambios
            xmlDoc.Save("Catalogos/catalogo.xml");

            // Mostrar mensaje de éxito
            MessageBox.Show("¡El videojuego ha sido modificado!");
        }
        // Función para validar si el valor es el valor por defecto
        private bool EsValorPorDefecto(string valor)
        {
            return valor == "Titulo" || valor == "Genero" || valor == "Desarrollador";
        }

        // ELIMINAR JUEGO
        private void EliminarJuego(XmlDocument xmlDoc)
        {
            // Obtener el título del videojuego desde el campo de texto
            string titulo = ((TextBox)this.Controls["txtTitulo"]).Text;

            if (string.IsNullOrEmpty(titulo))
            {
                MessageBox.Show("Por favor, ingrese un título para buscar el videojuego.");
                return;
            }

            // Buscar el videojuego por título
            XmlNode catalogoNode = xmlDoc.SelectSingleNode("Catalogo");
            XmlNode videojuegoNode = catalogoNode.SelectSingleNode($"Videojuego[Titulo='{titulo}']");

            // Si no se encuentra el videojuego
            if (videojuegoNode == null)
            {
                MessageBox.Show("No se ha encontrado un videojuego con ese título.");
                return;
            }

            // Eliminar el nodo del videojuego
            catalogoNode.RemoveChild(videojuegoNode);

            // Guardar los cambios en el archivo XML
            xmlDoc.Save("Catalogos/catalogo.xml");

            // Mostrar un mensaje de éxito
            MessageBox.Show("¡El videojuego ha sido eliminado del catálogo!");
        }

        // CARGAR XML INTERFAZ
        private XmlDocument CargarFicheroConfigInterfaz()
        {
            string interfazConfigPath = "Interfaz.xml";
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(interfazConfigPath);

            return xmlDoc;
        }

        // CARGAR XML CATALOGO
        private XmlDocument CargarCatalogo()
        {
            string catalogoConfigPath = "Catalogos/catalogo.xml";
            XmlDocument xmlDoc = new XmlDocument();

            // Verificar si el archivo XML existe antes de cargarlo
            if (System.IO.File.Exists(catalogoConfigPath))
            {
                xmlDoc.Load(catalogoConfigPath);
            }
            else
            {
                // Si el archivo no existe, crear un archivo nuevo con la estructura inicial
                XmlDeclaration xmlDeclaration = xmlDoc.CreateXmlDeclaration("1.0", "UTF-8", null);
                XmlNode root = xmlDoc.CreateElement("Catalogo");
                xmlDoc.AppendChild(xmlDeclaration);
                xmlDoc.AppendChild(root);
            }

            return xmlDoc;
        }

        #endregion
    }
}

